int plots( float *Mmx1, float *Mmx2, float *Mmy1, float *Mmy2, float *Sw, int *t );
