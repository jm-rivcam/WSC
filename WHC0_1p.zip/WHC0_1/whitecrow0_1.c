#include<stdio.h>
#include<string.h>
#include<math.h>
#include<unistd.h>
#include<stdlib.h>
#include<gtk/gtk.h>
#define BUFSIZE 1000

//made libraries
#include "libdata.h"
#include "libprop.h"
#include "libspectra.h"

float pi=3.14159;
float conv=1;

static void print_hello (GtkWidget *widget,
             gpointer   *data)
{
  g_print ("ON\n");
}

static void activate (GtkApplication *app,
          gpointer user_data)
{
  GtkWidget *window, *window1;
  GtkWidget *image, *image1;
  GtkWidget *box, *box1;


  box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
  image = gtk_image_new_from_file ("results/PM.png");
  window = gtk_application_window_new (app);

  box1 = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
  image1 = gtk_image_new_from_file ("results/JSWP.png");
  window1 = gtk_application_window_new (app);

  gtk_window_set_title (GTK_WINDOW (window), "Window");
  gtk_window_set_default_size (GTK_WINDOW (window), 600, 600);
  gtk_box_append (GTK_BOX (box), image);
  gtk_window_set_child (GTK_WINDOW (window), box);
  gtk_widget_set_size_request (image,600,600);
  gtk_widget_set_size_request (box,600,600);


  gtk_window_set_title (GTK_WINDOW (window1), "Window");
  gtk_window_set_default_size (GTK_WINDOW (window1), 600, 600);
  gtk_box_append (GTK_BOX (box1), image1);
  gtk_window_set_child (GTK_WINDOW (window1), box1);
  gtk_widget_set_size_request (image1,600,600);
  gtk_widget_set_size_request (box1,600,600);


  gtk_widget_show (image);
  gtk_widget_show (window);

  gtk_widget_show (image1);
  gtk_widget_show (window1);
}


int main(int argc, char **argv)
{
  int t=0;

//we read the size of the data file to store infromation on the arrays
t=read_ints();
t=t/3;

float nd[2], g=0;
int i=0;


//We proceed to declare the arrays that wil, be used to store the values from the data stream at the wind spectrum
  float *Em = malloc(t * sizeof(*Em));
  if (!Em) {
      printf("There was a problem with malloc.");
      exit(EXIT_FAILURE);
  }
  float *Ww = malloc(t * sizeof(*Ww));
  if (!Ww) {
      printf("There was a problem with malloc.");
      exit(EXIT_FAILURE);
  }

  float *Ft = malloc(t * sizeof(*Ft));
  if (!Ft) {
      printf("There was a problem with malloc.");
      exit(EXIT_FAILURE);
  }
  //Here we store the data from the file to each array as it corresponds
  FILE *fpa = fopen("example/data.txt", "r"); /* "r" = open for reading */
  char buff[BUFSIZE]; /* a buffer to hold what you read in */
int count=1, ip=0, ia=0, ix=0, iz=0, it=0, condit=1;

  //The program reads each data separated using a colon, the data consists on the spectral mode to calculate, the wind velocity and the fetch.
  while(!feof (fpa))
    {
      if(condit==0)
      {
        count=1;
        condit=1;
      }

       if (count==1)
      {
        fscanf(fpa, "%f", &Em[ip]);
        ip++;
      }

       if (count==2)
      {
        fscanf(fpa, "%f", &Ww[ix]);
        ix++;
      }

       if (count==3)
      {
        fscanf(fpa, "%f", &Ft[ia]);
        ia++;
        condit=0;
      }
      count++;

    }
  fclose(fpa);


  //Here we read the values of the depth and latitude that will be used for the gravitation and nondimensaional calculations
  read_nd(nd);
  //Here we calculate the gravity at the given latitute
  g=pl_gravity(nd[1]);

  //Here we start to calculate the two spectrums for the given wind conditions using the Pierson-Moskowitzz and the JONSWAPP formulations
  while (i<t)
  {
  pm(Em+i,Ww+i,Ft+i, i, &g, &pi);
    i++;
  }

  //GTK4+ is initialised
  GtkApplication *app;
  int status;
  //An app is created, app consists on the windows, boxes and files opened.
  app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
  g_signal_connect (app, "activate", G_CALLBACK (activate), NULL);
  status = g_application_run (G_APPLICATION (app), argc, argv);
  g_object_unref (app);



  return status;
}
