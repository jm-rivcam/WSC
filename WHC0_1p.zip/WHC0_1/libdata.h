int read_ints(void);
void read_nd(float *nd);
