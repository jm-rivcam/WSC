#include <stdio.h>

int read_ints(void)
{
  //Data is read from the fiel stream to determinate the number of spectra to calculate
  FILE *fp;
  fp=fopen("example/data.txt", "r");
  float i = 0, count=1;

  fscanf(fp, "%f", &i);
  while(!feof (fp))
    {
      fscanf(fp, "%f", &i);
      count++;
    }
    fp=NULL;
  fclose(fp);

  return count;
}
