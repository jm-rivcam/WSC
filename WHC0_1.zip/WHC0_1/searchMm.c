#include <stdio.h>

int searchMm(float *Mmy1, float *Mmy2, float *Sw)
{
  int condit=1, i=0;
  *Mmy1=*Sw;
  *Mmy2=*Sw;

  while(i<30)
  {
    if ((i+1)==30)
    {
     *Mmy1=*Mmy1;
     *Mmy2=*Mmy2;
      condit=0;
    }

    if (condit==1)
    {
      if(*Mmy1<Sw[i+1])
      {
        *Mmy1=*Mmy1;
      }
      else if (*Mmy1>Sw[i+1])
      {
        *Mmy1=Sw[i+1];
      }

      if(*Mmy2>Sw[i+1])
      {
        *Mmy2=*Mmy2;
      }
      else if (*Mmy2<Sw[i+1])
      {
        *Mmy2=Sw[i+1];
      }
    }
    Sw[i]=Sw[i+1];
    i++;

}
return 0;
}
