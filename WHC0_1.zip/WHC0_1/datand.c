#include <stdio.h>

void read_nd(float *nd)
{
//Data to be used to calculate the wave spectra is given by the user
printf("Introduce the depth were the waves propagate: ");
scanf("%f", nd);
printf("\n");
printf("Introduce the latitude of the buoy: ");
scanf("%f", nd+1);
}
