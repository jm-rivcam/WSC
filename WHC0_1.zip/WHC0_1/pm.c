#include <stdio.h>
#include <math.h>
#include "libseor.h"
#include "libplotsp.h"


int pm(float *Em, float *Wv, float *Ft, int i, float *g, float *pi)
{

  FILE *fp1, *fp2;
  //Create the files where the values (x,y) that define the spectra in this case one for the pierson moskowitz and one for the jonswapp spectra
  fp1 = fopen("results/spectrumpm.txt", "w");
  fp2 = fopen("results/spectrumjs.txt", "w");

  float alpha=0.0081, betha=0.74, a=0, b=0, wo=0, c=0, ftm=0, f=0, sup=0, inf=0;
  ftm=1000*(*Ft);
  float Tp[30]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,28,29,30};
  float Sw[30], Mmx[2]={0,0}, Mmy[2]={0,0};
  int t=0;
  //we declare some variables that will be used generally in some calculations
  a=alpha*(*g)*(*g);
  b=(2*(*pi));
  wo=((*g)/(*Wv));


if (*Em==0)//if Em=0 then the Pierson-Moskowitzz spectrum will be calculated
{
  while (t<=29)
  {
  f=1/Tp[t];
  c=b*f;
  Sw[t]=(a/(pow(c,5)))*exp(-betha*pow((wo/c),4));
  fprintf(fp1, "%.6f,%.3f", Sw[t],f);
  fprintf(fp1, "\t");
  t++;
  }
  Mmx[0]=0;//we declare the values of the maxima and minima to iniatlise its values
  Mmx[1]=1;
  t=0;
  searchMm(&Mmy[0],&Mmy[1],&Sw[0]);//Here we search for the max and min that will be used as markers for the plot dimensions
  plots(&Mmx[0], &Mmx[1], &Mmy[0], &Mmy[1], &Sw[0],&t); //We proceeed to plot the graphics of the spectrums using the maximum and minimal found to plot the graphcis and also we pass the variables related to the frequency/period vs spectral density
  fprintf(fp1, "\n");
  fp1=NULL;
  fclose(fp1);

}

else if(*Em==1)//if Em=1 then the JONSWAPP spectrum will be calculated
{
  float gamma=3.3, sigma=0, s1=0, s2=0, sa=0 ,sb=0;
  double lambda=0;

  betha=1.25;
  t=0;
  alpha=(0.076)*pow((((*Wv)*(*Wv))/(ftm*(*g))),0.22);
  a=alpha*(*g)*(*g);
  b=(2*(*pi));
  wo= 22*(pow((((*g)*(*g))/(*Wv*(ftm))),0.333333));
  while (t<=29)
  {
  f=1/Tp[t];
  c=b*f;
  if (c<=wo){
   sigma=0.07;
   }
   else if(c>wo){
   sigma=0.09;
   }
   sup=-pow((c-wo),2);
   inf=2*pow((sigma*wo),2);

   lambda=exp(sup/inf);

   sa=(a/(pow(c,5)));
   sb=exp(-betha*pow((wo/c),4));
   s1=sa*sb;
   s2=pow(gamma,lambda);
  Sw[t]=s1*s2;
  fprintf(fp2, "%.6f,%.3f", Sw[t],f);
  fprintf(fp2, "\t");
  t++;
  }
  Mmx[0]=0;//we declare the values of the maxima and minima to iniatlise its values
  Mmx[1]=1;
  t=1;
  searchMm(&Mmy[0],&Mmy[1],&Sw[0]);//Here we search for the max and min that will be used as markers for the plot dimensions
  plots(&Mmx[0],&Mmx[1],&Mmy[0],&Mmy[1],&Sw[0],&t);//We proceeed to plot the graphics of the spectrums using the maximum and minimal found to plot the graphcis and also we pass the variables related to the frequency/period vs spectral density
  fprintf(fp2, "\n");
  fp2=NULL;
  fclose(fp2);
}
else //if Em is differente than any option then a message saying which option is not valid will be given
{
  printf("option %d is not recognizable\n", i );
}


return 0;
}
