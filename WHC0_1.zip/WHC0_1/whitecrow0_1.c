#include<stdio.h>
#include<string.h>
#include<math.h>
#include<unistd.h>
#include<stdlib.h>
#define BUFSIZE 1000

//made libraries
#include "libdata.h"
#include "libprop.h"
#include "libspectra.h"

float pi=3.14159;
float conv=1;


int main(int argc, char **argv)
{
  int t=0;

//we read the size of the data file to store infromation on the arrays
t=read_ints();
t=t/3;

float nd[2], g=0;
int i=0;


//We proceed to declare the arrays that wil, be used to store the values from the data stream at the wind spectrum
  float *Em = malloc(t * sizeof(*Em));
  if (!Em) {
      printf("There was a problem with malloc.");
      exit(EXIT_FAILURE);
  }
  float *Ww = malloc(t * sizeof(*Ww));
  if (!Ww) {
      printf("There was a problem with malloc.");
      exit(EXIT_FAILURE);
  }

  float *Ft = malloc(t * sizeof(*Ft));
  if (!Ft) {
      printf("There was a problem with malloc.");
      exit(EXIT_FAILURE);
  }
  //Here we store the data from the file to each array as it corresponds
  FILE *fpa = fopen("example/data.txt", "r"); /* "r" = open for reading */
  char buff[BUFSIZE]; /* a buffer to hold what you read in */
int count=1, ip=0, ia=0, ix=0, iz=0, it=0, condit=1;

  //The program reads each data separated using a colon, the data consists on the spectral mode to calculate, the wind velocity and the fetch.
  while(!feof (fpa))
    {
      if(condit==0)
      {
        count=1;
        condit=1;
      }

       if (count==1)
      {
        fscanf(fpa, "%f", &Em[ip]);
        ip++;
      }

       if (count==2)
      {
        fscanf(fpa, "%f", &Ww[ix]);
        ix++;
      }

       if (count==3)
      {
        fscanf(fpa, "%f", &Ft[ia]);
        ia++;
        condit=0;
      }
      count++;

    }
  fclose(fpa);


  //Here we read the values of the depth and latitude that will be used for the gravitation and nondimensaional calculations
  read_nd(nd);
  //Here we calculate the gravity at the given latitute
  g=pl_gravity(nd[1]);

  //Here we start to calculate the two spectrums for the given wind conditions using the Pierson-Moskowitzz and the JONSWAPP formulations
  while (i<t)
  {
  pm(Em+i,Ww+i,Ft+i, i, &g, &pi);
    i++;
  }

 



  return 0;
}
