int searchMm(float *Mmy1, float *Mmy2, float *Sw);
