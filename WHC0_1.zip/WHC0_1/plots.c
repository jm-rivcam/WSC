#include <stdio.h>
#include </usr/local/opt/plplot/include/plplot/plplot.h> //long adress of plplot, you might need ot vchange this if you are not using brew, the easiast way is to use the command "find" in your terminal

int plots( float *Mmx1, float *Mmx2, float *Mmy1, float *Mmy2, float *Sw, int *t )
{
  int argc=1;
  char *argv[100]={""};
    int   i;
    PLFLT x[30], y[30];
    PLFLT xmin=0, xmax=30, ymin=0, ymax=0;
    ymin= *Mmy1;
    ymax= *Mmy2;

    // Prepare data to be plotted, here we rea the data and store it in arrays (x,y) to be used in plplot
    for ( i = 0; i <=29; i++ )
    {
        x[i] =  i ;
        y[i] =  Sw[i];
    }

    // Parse and process command line arguments
    plsdev (	"pngcairo");//we define that we are using the device pngcairo for our system, plsdev uses a set of device drives, so  pngcairo has to be avialable in our system to use it.
    if (*t==0)
    {
    plsfnam ("results/PM.png");//We set the name and location of our file
    }

    else if (*t==1)
    {
      plsfnam (	"results/JSWP.png" );//We set the name and location of our file
    }
    plparseopts( &argc, argv, PL_PARSE_FULL );//plparseopts is neccesary to pass command line arguments if need it

    // We Initialize plplot
    plinit();

    // Create a labelled box to hold the plot.
    plenv( xmin, xmax, ymin, ymax, 0, 0 );
    if (*t==0)
    {
      pllab( "T(s)", "D(m^2/Hz)", "PM Spectrum" );//Axis labels for our plots
    }

    else if (*t==1)
    {
      pllab( "T(s)", "D(m^2/Hz)", "JSW Spectrum" );//Axis labels for our plots
    }


    // Plot the data that was prepared above, using a line
    plline( i, x, y );

    // Close PLplot library
    plend();
return 0;
}
