#include <stdio.h>
#include <math.h>

float pl_gravity(float lat)

{
    float  g=0;
    //Gravity is calculated using a local geodesic projection
    g=( 9.780327 * (1+(0.0053024*(pow(sin(lat),2)))-(0.0000058*(pow(sin(lat),2)))) );
    return g;
}
