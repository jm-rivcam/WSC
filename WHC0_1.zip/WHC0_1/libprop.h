float pl_gravity(float lat);
