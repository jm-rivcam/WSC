int pm(float *Em, float *Wv, float *Ft, int i, float *g, float *pi);
